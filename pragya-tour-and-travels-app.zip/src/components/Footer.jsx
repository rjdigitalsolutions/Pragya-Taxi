
function Footer() {
  return (
    <footer className="bg-gray-900 text-white text-center py-4 mt-8">
      <p>&copy; 2025 Pragya Tour and Travels. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
