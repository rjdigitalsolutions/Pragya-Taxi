
function Home() {
  return (
    <section className="h-screen bg-cover bg-center flex items-center justify-center text-white text-center p-8" style={{ backgroundImage: "url('/src/assets/images/hero.jpg')" }}>
      <div className="bg-black bg-opacity-50 p-8 rounded-lg">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Ride With Comfort</h1>
        <p className="text-xl mb-6">Affordable. Reliable. Fast.</p>
        <a href="/book" className="bg-yellow-500 text-black px-6 py-2 rounded hover:bg-yellow-600 transition">Book Now</a>
      </div>
    </section>
  );
}

export default Home;
