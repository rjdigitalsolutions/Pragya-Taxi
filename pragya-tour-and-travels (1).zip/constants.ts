import { Car, CarCategory, Service, TripType } from './types';
import { Car as CarIcon, Plane, MapPin, Phone, ShieldCheck, Clock, Map } from 'lucide-react';

export const COMPANY_NAME = "Pragya Tour and Travels";
export const COMPANY_PHONE = "+91 99105 61795";
export const COMPANY_WHATSAPP = "919910561795";
export const COMPANY_EMAIL = "bookings@pragyatravels.in";
export const COMPANY_ADDRESS = "123, Transport Nagar, Jaipur, Rajasthan, India";

export const CARS: Car[] = [
  {
    id: 'sedan',
    name: 'Swift Dzire / Etios',
    category: CarCategory.SEDAN,
    image: 'https://picsum.photos/400/250?random=1',
    seats: 4,
    luggage: 2,
    ac: true,
    ratePerKm: 11,
    localPackages: {
      "4hr40km": 1200,
      "8hr80km": 2200,
      "12hr120km": 3000
    },
    driverAllowance: 300
  },
  {
    id: 'ertiga',
    name: 'Maruti Ertiga',
    category: CarCategory.MPV,
    image: 'https://picsum.photos/400/250?random=2',
    seats: 6,
    luggage: 3,
    ac: true,
    ratePerKm: 14,
    localPackages: {
      "4hr40km": 1600,
      "8hr80km": 2800,
      "12hr120km": 3800
    },
    driverAllowance: 300
  },
  {
    id: 'suv',
    name: 'Toyota Innova',
    category: CarCategory.SUV,
    image: 'https://picsum.photos/400/250?random=3',
    seats: 7,
    luggage: 4,
    ac: true,
    ratePerKm: 18,
    localPackages: {
      "4hr40km": 2000,
      "8hr80km": 3500,
      "12hr120km": 4500
    },
    driverAllowance: 400
  },
  {
    id: 'crysta',
    name: 'Innova Crysta',
    category: CarCategory.PREMIUM_SUV,
    image: 'https://picsum.photos/400/250?random=4',
    seats: 7,
    luggage: 4,
    ac: true,
    ratePerKm: 22,
    localPackages: {
      "4hr40km": 2500,
      "8hr80km": 4200,
      "12hr120km": 5500
    },
    driverAllowance: 500
  },
  {
    id: 'tempo',
    name: 'Tempo Traveller',
    category: CarCategory.TEMPO,
    image: 'https://picsum.photos/400/250?random=5',
    seats: 12,
    luggage: 10,
    ac: true,
    ratePerKm: 28,
    localPackages: {
      "4hr40km": 3500,
      "8hr80km": 6000,
      "12hr120km": 8000
    },
    driverAllowance: 600
  }
];

export const SERVICES: Service[] = [
  {
    id: 'local',
    title: 'Local Rental',
    description: 'Perfect for city tours, shopping, and business meetings. Available in 4hr, 8hr, and 12hr packages.',
    icon: 'Car'
  },
  {
    id: 'outstation',
    title: 'Outstation Cabs',
    description: 'Round trip or one-way drops to any city in India. Clean cars and expert drivers for long journeys.',
    icon: 'Map'
  },
  {
    id: 'airport',
    title: 'Airport Transfer',
    description: 'Reliable airport pickups and drops. Never miss a flight with our punctual service.',
    icon: 'Plane'
  }
];