import React, { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { Menu, X, Phone, MessageCircle, MapPin, Mail, Facebook, Twitter, Instagram } from 'lucide-react';
import { COMPANY_NAME, COMPANY_PHONE, COMPANY_WHATSAPP } from '../constants';

export default function Layout() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const closeMenu = () => setIsMenuOpen(false);

  // Helper to scroll to top on route change
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <div className="flex flex-col min-h-screen text-gray-800">
      {/* Top Bar */}
      <div className="bg-brand-dark text-white text-xs sm:text-sm py-2 px-4 hidden sm:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex space-x-6">
            <span className="flex items-center gap-2"><Phone size={14} className="text-brand-yellow" /> {COMPANY_PHONE}</span>
            <span className="flex items-center gap-2"><Mail size={14} className="text-brand-yellow" /> bookings@pragyatravels.in</span>
          </div>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-brand-yellow transition"><Facebook size={16} /></a>
            <a href="#" className="hover:text-brand-yellow transition"><Twitter size={16} /></a>
            <a href="#" className="hover:text-brand-yellow transition"><Instagram size={16} /></a>
          </div>
        </div>
      </div>

      {/* Navbar */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center">
              <NavLink to="/" className="flex items-center gap-2" onClick={closeMenu}>
                <div className="w-10 h-10 bg-brand-yellow rounded-lg flex items-center justify-center text-brand-dark font-bold text-xl shadow-sm">
                  P
                </div>
                <span className="font-display font-bold text-xl sm:text-2xl text-brand-blue tracking-tight">
                  Pragya<span className="text-brand-yellow">Travels</span>
                </span>
              </NavLink>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              {['Home', 'About', 'Services', 'Pricing', 'Contact'].map((item) => (
                <NavLink
                  key={item}
                  to={item === 'Home' ? '/' : `/${item.toLowerCase()}`}
                  className={({ isActive }) => 
                    `font-medium transition-colors duration-200 ${isActive ? 'text-brand-yellow font-bold' : 'text-gray-600 hover:text-brand-blue'}`
                  }
                >
                  {item}
                </NavLink>
              ))}
              <NavLink 
                to="/book-cab" 
                className="bg-brand-blue hover:bg-blue-800 text-white px-6 py-2.5 rounded-full font-medium transition shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
              >
                Book Now
              </NavLink>
            </div>

            {/* Mobile Menu Button */}
            <div className="flex items-center md:hidden">
              <button onClick={toggleMenu} className="text-gray-600 hover:text-brand-blue focus:outline-none">
                {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {['Home', 'About', 'Services', 'Pricing', 'Contact'].map((item) => (
                <NavLink
                  key={item}
                  to={item === 'Home' ? '/' : `/${item.toLowerCase()}`}
                  onClick={closeMenu}
                  className={({ isActive }) =>
                    `block px-3 py-2 rounded-md text-base font-medium ${isActive ? 'bg-brand-yellow/10 text-brand-blue' : 'text-gray-700 hover:bg-gray-50'}`
                  }
                >
                  {item}
                </NavLink>
              ))}
              <NavLink 
                to="/book-cab"
                onClick={closeMenu}
                className="block w-full text-center mt-4 bg-brand-yellow text-brand-dark px-3 py-3 rounded-lg font-bold shadow-md"
              >
                Book a Cab
              </NavLink>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow bg-slate-50">
        <Outlet />
      </main>

      {/* Fixed Call Actions (Mobile) */}
      <div className="fixed bottom-4 right-4 z-40 flex flex-col gap-3 md:hidden">
         <a href={`https://wa.me/${COMPANY_WHATSAPP}`} target="_blank" rel="noreferrer" className="bg-green-500 text-white p-3 rounded-full shadow-lg hover:bg-green-600 transition animate-bounce">
           <MessageCircle size={24} fill="white" />
         </a>
         <a href={`tel:${COMPANY_PHONE.replace(/\s/g, '')}`} className="bg-brand-blue text-white p-3 rounded-full shadow-lg hover:bg-blue-800 transition">
           <Phone size={24} fill="white" />
         </a>
      </div>

      {/* Footer */}
      <footer className="bg-brand-dark text-gray-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-1">
              <span className="font-display font-bold text-2xl text-white block mb-4">
                Pragya<span className="text-brand-yellow">Travels</span>
              </span>
              <p className="text-sm text-gray-400 mb-4">
                Providing reliable, safe, and comfortable taxi services across India for over 10 years.
              </p>
            </div>
            
            <div>
              <h3 className="text-white font-bold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li><NavLink to="/" className="hover:text-brand-yellow transition">Home</NavLink></li>
                <li><NavLink to="/about" className="hover:text-brand-yellow transition">About Us</NavLink></li>
                <li><NavLink to="/services" className="hover:text-brand-yellow transition">Services</NavLink></li>
                <li><NavLink to="/book-cab" className="hover:text-brand-yellow transition">Book a Cab</NavLink></li>
              </ul>
            </div>

            <div>
              <h3 className="text-white font-bold text-lg mb-4">Our Services</h3>
              <ul className="space-y-2 text-sm">
                <li>Local Car Rentals</li>
                <li>Outstation Round Trip</li>
                <li>One Way Drops</li>
                <li>Airport Transfers</li>
                <li>Corporate Car Rental</li>
              </ul>
            </div>

            <div>
              <h3 className="text-white font-bold text-lg mb-4">Contact Us</h3>
              <ul className="space-y-4 text-sm">
                <li className="flex items-start gap-3">
                  <MapPin size={18} className="text-brand-yellow shrink-0 mt-0.5" />
                  <span>123, Transport Nagar, Jaipur, Rajasthan, India</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone size={18} className="text-brand-yellow shrink-0" />
                  <a href={`tel:${COMPANY_PHONE.replace(/\s/g, '')}`} className="hover:text-white transition">{COMPANY_PHONE}</a>
                </li>
                <li className="flex items-center gap-3">
                  <Mail size={18} className="text-brand-yellow shrink-0" />
                  <a href="mailto:bookings@pragyatravels.in" className="hover:text-white transition">bookings@pragyatravels.in</a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} {COMPANY_NAME}. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
