import React, { useState } from 'react';
import { getTravelItinerary } from '../services/geminiService';
import { Sparkles, Map, Loader2, Send } from 'lucide-react';

export default function AIPlanner() {
  const [destination, setDestination] = useState('');
  const [days, setDays] = useState('3');
  const [style, setStyle] = useState('Family & Relaxed');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handlePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination) return;
    
    setLoading(true);
    setResult(null);
    const itinerary = await getTravelItinerary(destination, days, style);
    setResult(itinerary);
    setLoading(false);
  };

  return (
    <section className="py-16 bg-gradient-to-br from-brand-blue to-blue-900 text-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
         {/* Abstract background pattern could go here */}
         <div className="absolute -top-24 -left-24 w-64 h-64 bg-brand-yellow rounded-full blur-3xl"></div>
         <div className="absolute top-1/2 right-0 w-96 h-96 bg-purple-500 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <div>
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-1 rounded-full text-brand-yellow text-sm font-semibold mb-4 border border-white/20">
              <Sparkles size={16} />
              <span>Powered by AI</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-display font-bold mb-4">
              Not sure where to go? <br />
              <span className="text-brand-yellow">Ask our Smart Travel Guide.</span>
            </h2>
            <p className="text-blue-100 text-lg mb-8">
              Let our AI assistant plan your perfect trip in seconds. Get a customized itinerary based on your preferences.
            </p>

            <form onSubmit={handlePlan} className="space-y-4 bg-white/5 backdrop-blur-md p-6 rounded-2xl border border-white/10 shadow-2xl">
              <div>
                <label className="block text-sm font-medium text-blue-200 mb-1">Destination</label>
                <input 
                  type="text" 
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  placeholder="e.g. Jaipur, Manali, Goa"
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-blue-300/50 focus:outline-none focus:border-brand-yellow focus:ring-1 focus:ring-brand-yellow transition"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-1">Duration (Days)</label>
                  <select 
                    value={days}
                    onChange={(e) => setDays(e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-brand-yellow [&>option]:text-brand-dark"
                  >
                    {[1,2,3,4,5,7,10].map(d => <option key={d} value={d}>{d} Days</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-blue-200 mb-1">Travel Style</label>
                  <select 
                     value={style}
                     onChange={(e) => setStyle(e.target.value)}
                     className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-brand-yellow [&>option]:text-brand-dark"
                  >
                    <option>Family & Relaxed</option>
                    <option>Adventure & Nature</option>
                    <option>Heritage & Culture</option>
                    <option>Budget Backpacking</option>
                  </select>
                </div>
              </div>
              <button 
                type="submit" 
                disabled={loading || !destination}
                className="w-full bg-brand-yellow text-brand-dark font-bold py-3 rounded-lg hover:bg-yellow-400 transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? <Loader2 className="animate-spin" /> : <Send size={18} />}
                Generate Itinerary
              </button>
            </form>
          </div>

          <div className="bg-white/95 text-gray-800 p-6 rounded-2xl shadow-2xl min-h-[400px] max-h-[600px] overflow-y-auto">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-4">
                <Loader2 size={48} className="animate-spin text-brand-blue" />
                <p>Crafting your perfect journey...</p>
              </div>
            ) : result ? (
              <div className="prose prose-sm max-w-none">
                <div className="flex items-center gap-3 mb-6 border-b pb-4">
                  <div className="bg-green-100 p-2 rounded-full text-green-600">
                    <Map size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-gray-900">Your Itinerary for {destination}</h3>
                    <p className="text-xs text-gray-500">{days} Days • {style}</p>
                  </div>
                </div>
                <div 
                  className="space-y-4 text-gray-600 [&>h3]:text-brand-blue [&>h3]:font-bold [&>h3]:text-lg [&>h3]:mt-4 [&>ul]:list-disc [&>ul]:pl-5 [&>strong]:text-gray-900"
                  dangerouslySetInnerHTML={{ __html: result }} 
                />
                <div className="mt-8 pt-4 border-t text-center">
                  <p className="text-sm text-gray-500 mb-3">Like this plan?</p>
                  <a href="/book-cab" className="inline-block bg-brand-blue text-white px-6 py-2 rounded-full font-medium text-sm hover:bg-blue-800 transition">Book a Cab for this Trip</a>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-gray-400 opacity-60">
                <Map size={64} strokeWidth={1} />
                <p className="mt-4 text-center">Enter your destination details to see an AI-generated travel plan here.</p>
              </div>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}
