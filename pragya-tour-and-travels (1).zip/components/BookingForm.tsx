import React, { useState } from 'react';
import { TripType } from '../types';
import { Calendar, Clock, MapPin, Navigation } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function BookingForm() {
  const [activeTab, setActiveTab] = useState<TripType>(TripType.OUTSTATION);
  const [pickupCity, setPickupCity] = useState('');
  const [dropCity, setDropCity] = useState('');
  const [pickupDate, setPickupDate] = useState('');
  const [pickupTime, setPickupTime] = useState('');
  const [returnDate, setReturnDate] = useState('');

  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would pass state to the booking page or API
    // For now, we simulate navigating to the 'Book Cab' page with data
    navigate('/book-cab', { state: { activeTab, pickupCity, dropCity, pickupDate, pickupTime, returnDate } });
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 max-w-4xl mx-auto -mt-10 sm:-mt-24 relative z-10">
      {/* Tabs */}
      <div className="flex text-sm sm:text-base bg-gray-50 border-b">
        <button
          onClick={() => setActiveTab(TripType.OUTSTATION)}
          className={`flex-1 py-4 font-semibold transition-all ${
            activeTab === TripType.OUTSTATION ? 'bg-white text-brand-blue border-t-4 border-brand-yellow' : 'text-gray-500 hover:text-gray-800 hover:bg-gray-100'
          }`}
        >
          Outstation
        </button>
        <button
          onClick={() => setActiveTab(TripType.LOCAL)}
          className={`flex-1 py-4 font-semibold transition-all ${
            activeTab === TripType.LOCAL ? 'bg-white text-brand-blue border-t-4 border-brand-yellow' : 'text-gray-500 hover:text-gray-800 hover:bg-gray-100'
          }`}
        >
          Local Rental
        </button>
        <button
          onClick={() => setActiveTab(TripType.AIRPORT)}
          className={`flex-1 py-4 font-semibold transition-all ${
            activeTab === TripType.AIRPORT ? 'bg-white text-brand-blue border-t-4 border-brand-yellow' : 'text-gray-500 hover:text-gray-800 hover:bg-gray-100'
          }`}
        >
          Airport
        </button>
      </div>

      {/* Form Content */}
      <div className="p-6 sm:p-8">
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="md:col-span-2 lg:col-span-1">
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">From</label>
            <div className="flex items-center border rounded-lg px-3 py-2 bg-gray-50 focus-within:bg-white focus-within:ring-2 ring-brand-blue/20 transition">
              <MapPin size={18} className="text-gray-400 mr-2" />
              <input 
                type="text" 
                required 
                placeholder="Pickup City" 
                className="w-full bg-transparent outline-none text-gray-800 placeholder-gray-400"
                value={pickupCity}
                onChange={(e) => setPickupCity(e.target.value)}
              />
            </div>
          </div>

          {activeTab !== TripType.LOCAL && (
            <div className="md:col-span-2 lg:col-span-1">
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">To</label>
              <div className="flex items-center border rounded-lg px-3 py-2 bg-gray-50 focus-within:bg-white focus-within:ring-2 ring-brand-blue/20 transition">
                <Navigation size={18} className="text-gray-400 mr-2" />
                <input 
                  type="text" 
                  required={activeTab !== TripType.LOCAL}
                  placeholder="Drop City" 
                  className="w-full bg-transparent outline-none text-gray-800 placeholder-gray-400"
                  value={dropCity}
                  onChange={(e) => setDropCity(e.target.value)}
                />
              </div>
            </div>
          )}

          <div className="md:col-span-1">
             <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Pickup Date</label>
             <div className="flex items-center border rounded-lg px-3 py-2 bg-gray-50 focus-within:bg-white focus-within:ring-2 ring-brand-blue/20 transition">
              <Calendar size={18} className="text-gray-400 mr-2" />
              <input 
                type="date" 
                required 
                className="w-full bg-transparent outline-none text-gray-800 text-sm"
                value={pickupDate}
                onChange={(e) => setPickupDate(e.target.value)}
              />
            </div>
          </div>

          <div className="md:col-span-1">
             <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Pickup Time</label>
             <div className="flex items-center border rounded-lg px-3 py-2 bg-gray-50 focus-within:bg-white focus-within:ring-2 ring-brand-blue/20 transition">
              <Clock size={18} className="text-gray-400 mr-2" />
              <input 
                type="time" 
                required 
                className="w-full bg-transparent outline-none text-gray-800 text-sm"
                value={pickupTime}
                onChange={(e) => setPickupTime(e.target.value)}
              />
            </div>
          </div>

          {activeTab === TripType.OUTSTATION && (
            <div className="md:col-span-1">
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Return Date</label>
              <div className="flex items-center border rounded-lg px-3 py-2 bg-gray-50 focus-within:bg-white focus-within:ring-2 ring-brand-blue/20 transition">
                <Calendar size={18} className="text-gray-400 mr-2" />
                <input 
                  type="date" 
                  className="w-full bg-transparent outline-none text-gray-800 text-sm"
                  value={returnDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                />
              </div>
            </div>
          )}

          <div className={`md:col-span-2 ${activeTab === TripType.OUTSTATION ? 'lg:col-span-3' : 'lg:col-span-4'} flex items-end justify-center mt-2`}>
            <button type="submit" className="w-full bg-brand-yellow hover:bg-yellow-400 text-brand-dark font-bold py-3 rounded-lg shadow-md hover:shadow-lg transition transform hover:-translate-y-0.5 text-lg">
              Search Cabs
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}