import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || "";
const ai = new GoogleGenAI({ apiKey });

export const getTravelItinerary = async (destination: string, days: string, style: string) => {
  if (!apiKey) {
    console.warn("API Key is missing for Gemini");
    return "Please configure the API Key to use the AI Planner.";
  }

  try {
    const model = "gemini-2.5-flash";
    const prompt = `
      Act as an expert travel guide for India.
      Create a short, engaging ${days}-day travel itinerary for a trip to ${destination}.
      Travel Style: ${style}.
      
      Format the output as a simple HTML string (using only <h3>, <ul>, <li>, <p>, <strong> tags) so I can render it safely. 
      Do not include <html>, <body> or markdown code blocks. Just the inner HTML content.
      Focus on key attractions, local food recommendations, and best time to visit.
      Keep it concise (under 300 words total).
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I couldn't generate an itinerary right now. Please try again later.";
  }
};
