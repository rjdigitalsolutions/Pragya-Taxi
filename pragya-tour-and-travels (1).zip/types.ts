export enum CarCategory {
  SEDAN = 'Sedan',
  SUV = 'SUV',
  PREMIUM_SUV = 'Premium SUV', // Crysta
  MPV = 'MPV', // Ertiga
  TEMPO = 'Tempo Traveller'
}

export enum TripType {
  LOCAL = 'local',
  OUTSTATION = 'outstation',
  AIRPORT = 'airport'
}

export interface Car {
  id: string;
  name: string;
  category: CarCategory;
  image: string;
  seats: number;
  luggage: number;
  ac: boolean;
  ratePerKm: number; // For outstation
  localPackages: {
    [key: string]: number; // "8hr80km": 2000
  };
  driverAllowance: number;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface BookingDetails {
  tripType: TripType;
  pickupCity: string;
  dropCity?: string;
  pickupDate: string;
  pickupTime: string;
  returnDate?: string;
  duration?: string; // For local (e.g., "8hr80km")
  selectedCarId?: string;
}
