import React from 'react';
import BookingForm from '../components/BookingForm';
import AIPlanner from '../components/AIPlanner';
import { CARS, SERVICES, COMPANY_PHONE } from '../constants';
import { ShieldCheck, Clock, Award, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative bg-gray-900 min-h-[600px] flex flex-col justify-start pt-32 pb-48 items-center text-center px-4 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?ixlib=rb-4.0.3&auto=format&fit=crop&w=2021&q=80" 
            alt="Travel Background" 
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/40 to-transparent"></div>
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-display font-bold text-white mb-6 leading-tight">
            Explore India with <br/>
            <span className="text-brand-yellow">Comfort & Safety</span>
          </h1>
          <p className="text-gray-300 text-lg sm:text-xl mb-8 max-w-2xl mx-auto">
            Premium outstation cabs, local rentals, and airport transfers at the best prices. Book your ride today with Pragya Tour and Travels.
          </p>
        </div>
      </section>

      {/* Booking Form Widget */}
      <section className="px-4">
        <BookingForm />
      </section>

      {/* Services Section */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-display font-bold text-gray-900">Our Services</h2>
          <p className="text-gray-600 mt-2">Comprehensive travel solutions for every need</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {SERVICES.map((service) => (
            <div key={service.id} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition border border-gray-100 group">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center text-brand-blue mb-6 group-hover:bg-brand-blue group-hover:text-white transition">
                {/* We render a generic icon based on ID for simplicity or import specific ones */}
                {service.id === 'airport' && <Clock size={32} />}
                {service.id === 'local' && <ShieldCheck size={32} />}
                {service.id === 'outstation' && <Award size={32} />}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-gray-500 leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Fleet Showcase */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl font-display font-bold text-gray-900">Our Fleet</h2>
              <p className="text-gray-600 mt-2">Clean, well-maintained cars for every budget</p>
            </div>
            <Link to="/pricing" className="hidden sm:block text-brand-blue font-semibold hover:text-blue-800">View Full Pricing &rarr;</Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {CARS.slice(0, 4).map((car) => (
              <div key={car.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-lg transition group">
                <div className="h-48 overflow-hidden">
                  <img src={car.image} alt={car.name} className="w-full h-full object-cover transform group-hover:scale-110 transition duration-500" />
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-lg text-gray-900">{car.name}</h3>
                  <p className="text-sm text-gray-500 mb-4">{car.category} • {car.seats} Seater</p>
                  <div className="flex items-center justify-between">
                    <span className="text-brand-blue font-bold">₹{car.ratePerKm}/km</span>
                    <Link to="/book-cab" className="px-4 py-2 bg-brand-yellow/10 text-brand-dark text-sm font-semibold rounded-lg hover:bg-brand-yellow transition">Book</Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-8 text-center sm:hidden">
             <Link to="/pricing" className="text-brand-blue font-semibold">View All Cars &rarr;</Link>
          </div>
        </div>
      </section>

      {/* AI Planner Section */}
      <AIPlanner />

      {/* Why Choose Us */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="relative">
             <img 
               src="https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
               alt="Driver" 
               className="rounded-2xl shadow-2xl"
             />
             <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-xl shadow-xl max-w-xs hidden md:block">
               <div className="flex items-center gap-4">
                 <div className="bg-green-100 p-3 rounded-full">
                   <Phone className="text-green-600" size={24} />
                 </div>
                 <div>
                   <p className="text-xs text-gray-500 uppercase font-bold">24/7 Support</p>
                   <p className="font-bold text-gray-900">{COMPANY_PHONE}</p>
                 </div>
               </div>
             </div>
          </div>
          <div>
            <h2 className="text-3xl font-display font-bold text-gray-900 mb-6">Why Travel with Pragya Tours?</h2>
            <div className="space-y-6">
              {[
                { title: 'Expert Chauffeurs', desc: 'Verified, polite, and experienced drivers who know the routes well.' },
                { title: 'No Hidden Charges', desc: 'Transparent billing. What you see is what you pay. Tolls & parking extra.' },
                { title: 'Sanitized Cars', desc: 'Strict hygiene protocols followed before every trip.' },
                { title: 'Punctuality', desc: 'On-time pickup and drop, guaranteed.' }
              ].map((item, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className="w-12 h-12 shrink-0 bg-brand-blue/10 rounded-full flex items-center justify-center text-brand-blue font-bold">
                    {idx + 1}
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">{item.title}</h4>
                    <p className="text-sm text-gray-500">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}