import React from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import { COMPANY_ADDRESS, COMPANY_EMAIL, COMPANY_PHONE } from '../constants';

export default function ContactPage() {
  return (
    <div className="bg-white min-h-screen">
      <div className="bg-brand-dark py-16 px-4 text-center">
        <h1 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">Get in Touch</h1>
        <p className="text-gray-400">We are here to help you 24/7</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          
          {/* Contact Info */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Contact Information</h2>
            <p className="text-gray-600 mb-8">
              Whether you need to book a cab instantly or plan a long trip, our support team is available around the clock to assist you.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-blue-100 p-3 rounded-full text-brand-blue">
                  <Phone size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">Phone</h3>
                  <p className="text-gray-600">{COMPANY_PHONE}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-blue-100 p-3 rounded-full text-brand-blue">
                  <Mail size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">Email</h3>
                  <p className="text-gray-600">{COMPANY_EMAIL}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-blue-100 p-3 rounded-full text-brand-blue">
                  <MapPin size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">Office Address</h3>
                  <p className="text-gray-600">{COMPANY_ADDRESS}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-blue-100 p-3 rounded-full text-brand-blue">
                  <Clock size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">Working Hours</h3>
                  <p className="text-gray-600">24 Hours / 7 Days a week</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-gray-50 p-8 rounded-2xl shadow-sm border border-gray-100">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Send us a Message</h2>
            <form className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Name</label>
                  <input type="text" className="w-full border-gray-300 rounded-lg p-3 border focus:ring-2 focus:ring-brand-yellow outline-none" placeholder="Your Name" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Phone</label>
                  <input type="tel" className="w-full border-gray-300 rounded-lg p-3 border focus:ring-2 focus:ring-brand-yellow outline-none" placeholder="Your Phone" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Email</label>
                <input type="email" className="w-full border-gray-300 rounded-lg p-3 border focus:ring-2 focus:ring-brand-yellow outline-none" placeholder="Your Email" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Message</label>
                <textarea rows={4} className="w-full border-gray-300 rounded-lg p-3 border focus:ring-2 focus:ring-brand-yellow outline-none" placeholder="How can we help?"></textarea>
              </div>
              <button className="w-full bg-brand-blue text-white font-bold py-3 rounded-lg hover:bg-blue-800 transition">Send Message</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
