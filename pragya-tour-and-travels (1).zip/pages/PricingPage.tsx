import React from 'react';
import { CARS } from '../constants';
import { Check, X } from 'lucide-react';

export default function PricingPage() {
  return (
    <div className="bg-white pb-20">
      <div className="bg-brand-dark py-20 px-4 text-center">
        <h1 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">Transparent Pricing</h1>
        <p className="text-gray-400 max-w-2xl mx-auto">Choose the perfect car for your journey. Competitive rates for local and outstation travel.</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10">
        <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-gray-100">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="p-4 md:p-6 font-bold text-gray-600">Car Type</th>
                  <th className="p-4 md:p-6 font-bold text-gray-600">Seating</th>
                  <th className="p-4 md:p-6 font-bold text-gray-600">Rate/Km (Outstation)</th>
                  <th className="p-4 md:p-6 font-bold text-gray-600">Driver Allowance</th>
                  <th className="p-4 md:p-6 font-bold text-gray-600">8Hr / 80Km (Local)</th>
                  <th className="p-4 md:p-6 font-bold text-gray-600">Action</th>
                </tr>
              </thead>
              <tbody>
                {CARS.map((car, index) => (
                  <tr key={car.id} className={`hover:bg-blue-50/30 transition ${index !== CARS.length - 1 ? 'border-b border-gray-100' : ''}`}>
                    <td className="p-4 md:p-6">
                      <div className="flex items-center gap-4">
                        <img src={car.image} alt={car.name} className="w-16 h-10 object-cover rounded shadow-sm hidden sm:block" />
                        <div>
                          <p className="font-bold text-gray-900">{car.name}</p>
                          <p className="text-xs text-gray-500">{car.category}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 md:p-6 text-gray-600">
                      {car.seats} + 1 Driver
                    </td>
                    <td className="p-4 md:p-6">
                      <span className="font-bold text-brand-blue">₹{car.ratePerKm}</span>
                    </td>
                    <td className="p-4 md:p-6 text-gray-600">
                      ₹{car.driverAllowance}/day
                    </td>
                    <td className="p-4 md:p-6 text-gray-600">
                      ₹{car.localPackages["8hr80km"]}
                    </td>
                    <td className="p-4 md:p-6">
                      <a href="/book-cab" className="text-brand-blue font-bold text-sm hover:underline">Book Now</a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
             <h3 className="font-bold text-lg mb-4 text-gray-900">Terms & Conditions (Outstation)</h3>
             <ul className="space-y-3 text-sm text-gray-600">
               <li className="flex gap-2"><Check size={16} className="text-green-500 shrink-0" /> Minimum billing of 250km/300km per day per car.</li>
               <li className="flex gap-2"><Check size={16} className="text-green-500 shrink-0" /> Toll tax, state tax, and parking charges are extra.</li>
               <li className="flex gap-2"><Check size={16} className="text-green-500 shrink-0" /> Driver allowance covers driver's food and stay.</li>
               <li className="flex gap-2"><Check size={16} className="text-green-500 shrink-0" /> Night driving charges applicable between 10 PM to 6 AM.</li>
             </ul>
          </div>
          <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
             <h3 className="font-bold text-lg mb-4 text-gray-900">Terms & Conditions (Local)</h3>
             <ul className="space-y-3 text-sm text-gray-600">
               <li className="flex gap-2"><Check size={16} className="text-green-500 shrink-0" /> Packages available: 4Hr/40km, 8Hr/80km, 12Hr/120km.</li>
               <li className="flex gap-2"><Check size={16} className="text-green-500 shrink-0" /> Extra km and extra hour charges apply after package limit.</li>
               <li className="flex gap-2"><Check size={16} className="text-green-500 shrink-0" /> Toll and parking excluded from the package price.</li>
             </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
