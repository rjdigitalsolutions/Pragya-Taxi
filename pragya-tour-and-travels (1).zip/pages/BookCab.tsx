import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { CARS, COMPANY_WHATSAPP } from '../constants';
import { BookingDetails, TripType } from '../types';
import { CheckCircle } from 'lucide-react';

export default function BookCab() {
  const location = useLocation();
  const initialState = (location.state as BookingDetails) || {
    tripType: TripType.OUTSTATION,
    pickupCity: '',
    pickupDate: '',
    pickupTime: '',
  };

  const [formData, setFormData] = useState<BookingDetails>(initialState);
  const [selectedCar, setSelectedCar] = useState<string>('');
  const [submitted, setSubmitted] = useState(false);

  const handleCarSelect = (id: string) => {
    setSelectedCar(id);
  };

  const confirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if(!selectedCar) {
      alert("Please select a car to proceed");
      return;
    }
    setSubmitted(true);
  };

  if (submitted) {
    const carDetails = CARS.find(c => c.id === selectedCar);
    const message = `Hello, I want to book a cab.%0A%0AType: ${formData.tripType}%0APickup: ${formData.pickupCity}%0ADrop: ${formData.dropCity || 'N/A'}%0ADate: ${formData.pickupDate}%0ACar: ${carDetails?.name}`;
    
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-4 text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-6 animate-bounce">
          <CheckCircle size={40} />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Booking Request Received!</h2>
        <p className="text-gray-600 max-w-md mb-8">
          Thank you for choosing Pragya Tour and Travels. Our team will contact you shortly to confirm your booking.
        </p>
        <div className="space-y-4">
          <a 
            href={`https://wa.me/${COMPANY_WHATSAPP}?text=${message}`}
            target="_blank"
            rel="noreferrer"
            className="block w-full sm:w-auto px-8 py-3 bg-[#25D366] text-white font-bold rounded-full hover:bg-green-600 transition shadow-lg"
          >
            Confirm via WhatsApp
          </a>
          <button 
            onClick={() => setSubmitted(false)}
            className="block w-full sm:w-auto px-8 py-3 text-gray-500 hover:text-gray-800 underline"
          >
            Edit Booking
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Complete Your Booking</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Booking Details Form */}
        <div className="lg:col-span-1 bg-white p-6 rounded-xl shadow-sm border border-gray-100 h-fit">
          <h2 className="text-xl font-bold mb-4">Trip Details</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-500 mb-1">Trip Type</label>
              <select 
                className="w-full border rounded p-2 bg-gray-50"
                value={formData.tripType}
                onChange={(e) => setFormData({...formData, tripType: e.target.value as TripType})}
              >
                <option value={TripType.LOCAL}>Local Rental</option>
                <option value={TripType.OUTSTATION}>Outstation</option>
                <option value={TripType.AIRPORT}>Airport Transfer</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-500 mb-1">Pickup City</label>
              <input 
                type="text" 
                className="w-full border rounded p-2"
                value={formData.pickupCity}
                onChange={(e) => setFormData({...formData, pickupCity: e.target.value})}
              />
            </div>
            {formData.tripType !== TripType.LOCAL && (
               <div>
                <label className="block text-sm text-gray-500 mb-1">Drop City</label>
                <input 
                  type="text" 
                  className="w-full border rounded p-2"
                  value={formData.dropCity || ''}
                  onChange={(e) => setFormData({...formData, dropCity: e.target.value})}
                />
              </div>
            )}
            <div>
              <label className="block text-sm text-gray-500 mb-1">Date</label>
              <input 
                type="date" 
                className="w-full border rounded p-2"
                value={formData.pickupDate}
                onChange={(e) => setFormData({...formData, pickupDate: e.target.value})}
              />
            </div>
          </div>
        </div>

        {/* Car Selection */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-bold">Select Vehicle</h2>
          <div className="grid gap-4">
            {CARS.map((car) => (
              <div 
                key={car.id} 
                onClick={() => handleCarSelect(car.id)}
                className={`flex flex-col sm:flex-row bg-white border-2 rounded-xl overflow-hidden cursor-pointer transition hover:shadow-md ${selectedCar === car.id ? 'border-brand-blue ring-2 ring-brand-blue/20' : 'border-transparent'}`}
              >
                <div className="w-full sm:w-1/3 h-48 sm:h-auto">
                  <img src={car.image} alt={car.name} className="w-full h-full object-cover" />
                </div>
                <div className="p-6 flex-grow flex flex-col justify-center">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{car.name}</h3>
                      <p className="text-sm text-gray-500">{car.category} • {car.seats} Seater</p>
                    </div>
                    <div className="text-right">
                      {formData.tripType === TripType.OUTSTATION ? (
                        <>
                          <span className="block text-xl font-bold text-brand-blue">₹{car.ratePerKm}</span>
                          <span className="text-xs text-gray-500">per km</span>
                        </>
                      ) : (
                         <>
                          <span className="block text-xl font-bold text-brand-blue">₹{car.localPackages["8hr80km"]}</span>
                          <span className="text-xs text-gray-500">8hr/80km</span>
                        </>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-600 mt-2">
                     <span>AC: {car.ac ? 'Yes' : 'No'}</span>
                     <span>Luggage: {car.luggage} Bags</span>
                  </div>
                </div>
                <div className="p-4 flex items-center justify-center border-l border-gray-100">
                   <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${selectedCar === car.id ? 'border-brand-blue' : 'border-gray-300'}`}>
                      {selectedCar === car.id && <div className="w-3 h-3 bg-brand-blue rounded-full"></div>}
                   </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end pt-4">
            <button 
              onClick={confirmBooking}
              disabled={!selectedCar}
              className="bg-brand-yellow text-brand-dark font-bold text-lg px-8 py-3 rounded-lg shadow-lg hover:bg-yellow-400 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Confirm Booking
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
