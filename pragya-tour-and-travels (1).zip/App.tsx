import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import PricingPage from './pages/PricingPage';
import ContactPage from './pages/ContactPage';
import BookCab from './pages/BookCab';

// Placeholder components for simpler pages
const About = () => (
  <div className="max-w-7xl mx-auto px-4 py-20 text-center">
    <h1 className="text-4xl font-bold text-brand-dark mb-6">About Pragya Travels</h1>
    <div className="prose mx-auto text-gray-600 max-w-3xl">
      <p className="mb-4">
        Pragya Tour and Travels has been a trusted name in the Indian transportation industry for over a decade.
        We specialize in providing safe, reliable, and comfortable taxi services across major cities in India.
      </p>
      <p>
        Our fleet consists of well-maintained Sedans, SUVs, and Tempo Travellers driven by professional chauffeurs.
        Whether it's a corporate meeting, a family vacation, or an airport transfer, we ensure a hassle-free experience.
      </p>
    </div>
  </div>
);

const Services = () => (
  <div className="max-w-7xl mx-auto px-4 py-20">
    <h1 className="text-4xl font-bold text-brand-dark mb-10 text-center">Our Services</h1>
    <div className="grid md:grid-cols-2 gap-8">
      <div className="bg-white p-8 rounded-xl shadow-md">
        <h3 className="text-2xl font-bold mb-4">Corporate Travel</h3>
        <p className="text-gray-600">Dedicated employee transportation and executive car rentals with monthly billing options.</p>
      </div>
      <div className="bg-white p-8 rounded-xl shadow-md">
        <h3 className="text-2xl font-bold mb-4">Wedding Car Rental</h3>
        <p className="text-gray-600">Luxury cars for weddings and events. Decor options available upon request.</p>
      </div>
      <div className="bg-white p-8 rounded-xl shadow-md">
        <h3 className="text-2xl font-bold mb-4">Tour Packages</h3>
        <p className="text-gray-600">Customized Rajasthan, Himachal, and Golden Triangle tour packages.</p>
      </div>
      <div className="bg-white p-8 rounded-xl shadow-md">
        <h3 className="text-2xl font-bold mb-4">Pilgrimage Tours</h3>
        <p className="text-gray-600">Special packages for Char Dham, Vaishno Devi, and other religious sites.</p>
      </div>
    </div>
  </div>
);

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="about" element={<About />} />
          <Route path="services" element={<Services />} />
          <Route path="pricing" element={<PricingPage />} />
          <Route path="contact" element={<ContactPage />} />
          <Route path="book-cab" element={<BookCab />} />
        </Route>
      </Routes>
    </Router>
  );
}
